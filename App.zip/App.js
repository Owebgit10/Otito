import React, { useState } from 'react';

function App() {
  const [amount, setAmount] = useState('');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('EUR');
  const [result, setResult] = useState('');

  const handleAmountChange = (event) => {
    const value = event.target.value;

    if (/^\d*\.?\d*$/.test(value)) {
      setAmount(value);
    } else if (value === '') {
      alert('Please input a number.');
    } else {
      alert('Please input a valid number.');
    }
  };

  const handleFromCurrencyChange = (e) => {
    setFromCurrency(e.target.value);
  };

  const handleToCurrencyChange = (e) => {
    setToCurrency(e.target.value);
  };

  const handleSwap = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
  };

  const handleSubmit = async () => {
    try {
      const apiKey = 'cca3a3bc3eb5135c35076614';
      const response = await fetch(`https://v6.exchangerate-api.com/v6/cca3a3bc3eb5135c35076614/latest/${fromCurrency}`);
      const data = await response.json();

      if (data.result === 'success') {
        const rate = data.conversion_rates[toCurrency];
        const convertedAmount = (amount * rate).toFixed(2);
        setResult(`${amount} ${fromCurrency} = ${convertedAmount} ${toCurrency}`);
      } else {
        setResult('Error fetching data. Please try again.');
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setResult('Error fetching data. Please try again.');
    }
  };

  return (
    <div className="app">
      <h1>Currency Converter</h1>
      <div>
        <label>
          Amount:
          <input type="text" value={amount} onChange={handleAmountChange} />
        </label>
      </div>
      <div>
        <label>
          From Currency:
          <select value={fromCurrency} onChange={handleFromCurrencyChange}>
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
            <option value="JPY">JPY</option>
            <option value="CAD">CAD</option>
            <option value="AUD">AUD</option>
          </select>
        </label>
      </div>
      <div>
        <label>
          To Currency:
          <select value={toCurrency} onChange={handleToCurrencyChange}>
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
            <option value="JPY">JPY</option>
            <option value="CAD">CAD</option>
            <option value="AUD">AUD</option>
          </select>
        </label>
      </div>
      <div>
        <button onClick={handleSubmit}>Convert</button>
        <button onClick={handleSwap}>Swap</button>
      </div>
      <div>
        <h2>{result}</h2>
      </div>
    </div>
  );
}

export default App;







